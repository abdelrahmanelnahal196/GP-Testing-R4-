package com.phptravels.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class HotelPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    private final By locationField = By.cssSelector("input[name='location'], input[name='city'], input[placeholder*='City'], input[placeholder*='Location']");
    private final By checkInField = By.cssSelector("input[name='checkin'], input[name='check_in'], input[placeholder*='Check']");
    private final By checkOutField = By.cssSelector("input[name='checkout'], input[name='check_out'], input[placeholder*='Check']");
    private final By searchButton = By.cssSelector("form button[type='submit'], .search_button, button.search, input[type='submit']");

    private final By autoCompleteSuggestion = By.cssSelector(".autoComplete_result, .tt-suggestion, .select2-results__option, .autocomplete-result");
    private final By hotelCard = By.cssSelector(".hotel-item, .card-hotel, .hotel-list, [data-testid='hotel-card']");
    private final By noResultsMsg = By.cssSelector(".no-results, .alert-warning, .alert-danger, .empty, .not-found");
    private final By hotelName = By.cssSelector(".hotel-item .title, .card-hotel .name, .hotel-name, h3, h4");
    private final By validationMsg = By.cssSelector(".parsley-required, .invalid-feedback, .error, .alert-danger, .text-danger");

    public HotelPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    public void navigateTo(String baseUrl) {
        driver.get(baseUrl + "/hotels");
    }

    public void enterLocation(String location) {
        typeAndSelectRequiredSuggestion(locationField, location, "hotel location");
    }

    public void enterLocationWithoutSuggestion(String location) {
        typeOnly(locationField, location);
    }

    public void setCheckIn(String date) {
        setDate(checkInField, date);
    }

    public void setCheckOut(String date) {
        setDate(checkOutField, date);
    }

    public void clickSearch() {
        wait.until(ExpectedConditions.elementToBeClickable(searchButton)).click();
    }

    public boolean areResultsDisplayed() {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(hotelCard));
            return getResultCount() > 0;
        } catch (TimeoutException e) {
            return false;
        }
    }

    public int getResultCount() {
        return driver.findElements(hotelCard).size();
    }

    public boolean isNoResultsMessageDisplayed() {
        return isVisible(noResultsMsg);
    }

    public boolean isValidationMessageDisplayed() {
        return isVisible(validationMsg) || hasInvalidRequiredFields();
    }

    public boolean isSearchHandledGracefully() {
        return areResultsDisplayed() || isNoResultsMessageDisplayed() || isValidationMessageDisplayed();
    }

    public String getFirstHotelName() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(hotelName)).getText().trim();
    }

    private void typeAndSelectRequiredSuggestion(By fieldLocator, String value, String fieldName) {
        typeOnly(fieldLocator, value);
        try {
            WebElement suggestion = wait.until(ExpectedConditions.elementToBeClickable(autoCompleteSuggestion));
            suggestion.click();
        } catch (TimeoutException e) {
            throw new AssertionError("Autocomplete suggestion did not appear for " + fieldName + ": " + value, e);
        }
    }

    private void typeOnly(By fieldLocator, String value) {
        WebElement field = wait.until(ExpectedConditions.elementToBeClickable(fieldLocator));
        field.clear();
        field.sendKeys(value);
    }

    private void setDate(By dateLocator, String date) {
        WebElement field = wait.until(ExpectedConditions.presenceOfElementLocated(dateLocator));
        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].removeAttribute('readonly');" +
                "arguments[0].value = arguments[1];" +
                "arguments[0].dispatchEvent(new Event('input', { bubbles: true }));" +
                "arguments[0].dispatchEvent(new Event('change', { bubbles: true }));",
                field,
                date
        );
    }

    private boolean isVisible(By locator) {
        try {
            return wait.until(ExpectedConditions.visibilityOfElementLocated(locator)).isDisplayed();
        } catch (TimeoutException e) {
            return false;
        }
    }

    private boolean hasInvalidRequiredFields() {
        List<WebElement> fields = driver.findElements(By.cssSelector("input, select, textarea"));
        for (WebElement field : fields) {
            Object valid = ((JavascriptExecutor) driver).executeScript("return arguments[0].checkValidity ? arguments[0].checkValidity() : true;", field);
            if (Boolean.FALSE.equals(valid)) {
                return true;
            }
        }
        return false;
    }
}
