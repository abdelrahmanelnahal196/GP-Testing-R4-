package com.phptravels.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class FlightPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    private final By oneWayRadio = By.cssSelector("input[value='oneway'], input[value='one-way'], input[name='triptype'][value='oneway']");
    private final By roundTripRadio = By.cssSelector("input[value='roundtrip'], input[value='round-trip'], input[name='triptype'][value='roundtrip']");
    private final By fromField = By.cssSelector("input[name='from'], input[name='origin'], input[placeholder*='From']");
    private final By toField = By.cssSelector("input[name='to'], input[name='destination'], input[placeholder*='To']");
    private final By departureDateField = By.cssSelector("input[name='departure_date'], input[name='departure'], input[placeholder*='Depart']");
    private final By returnDateField = By.cssSelector("input[name='return_date'], input[name='return'], input[placeholder*='Return']");
    private final By searchButton = By.cssSelector("form button[type='submit'], .search_button, button.search, input[type='submit']");

    private final By autoCompleteSuggestion = By.cssSelector(".autoComplete_result, .tt-suggestion, .select2-results__option, .autocomplete-result");
    private final By resultsContainer = By.cssSelector(".flight-item, .list-flights, .flight-list, .card-flight, [data-testid='flight-card']");
    private final By noResultsMsg = By.cssSelector(".no-results, .alert-warning, .alert-danger, .empty, .not-found");
    private final By validationMsg = By.cssSelector(".parsley-required, .invalid-feedback, .error, .alert-danger, .text-danger");

    public FlightPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    public void navigateTo(String baseUrl) {
        driver.get(baseUrl + "/flights");
    }

    public void selectOneWay() {
        clickIfPresent(oneWayRadio);
    }

    public void selectRoundTrip() {
        clickIfPresent(roundTripRadio);
    }

    public void enterOrigin(String origin) {
        typeAndSelectRequiredSuggestion(fromField, origin, "origin");
    }

    public void enterDestination(String destination) {
        typeAndSelectRequiredSuggestion(toField, destination, "destination");
    }

    public void enterDestinationWithoutSuggestion(String destination) {
        typeOnly(toField, destination);
    }

    public void setDepartureDate(String date) {
        setDate(departureDateField, date);
    }

    public void setReturnDate(String date) {
        setDate(returnDateField, date);
    }

    public void clickSearch() {
        wait.until(ExpectedConditions.elementToBeClickable(searchButton)).click();
    }

    public boolean areResultsDisplayed() {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(resultsContainer));
            return getResultCount() > 0;
        } catch (TimeoutException e) {
            return false;
        }
    }

    public int getResultCount() {
        return driver.findElements(resultsContainer).size();
    }

    public boolean isNoResultsMessageDisplayed() {
        return isVisible(noResultsMsg);
    }

    public boolean isValidationMessageDisplayed() {
        return isVisible(validationMsg) || hasInvalidRequiredFields();
    }

    public boolean isSearchHandledGracefully() {
        return areResultsDisplayed() || isNoResultsMessageDisplayed() || isValidationMessageDisplayed();
    }

    private void typeAndSelectRequiredSuggestion(By fieldLocator, String value, String fieldName) {
        typeOnly(fieldLocator, value);
        try {
            WebElement suggestion = wait.until(ExpectedConditions.elementToBeClickable(autoCompleteSuggestion));
            suggestion.click();
        } catch (TimeoutException e) {
            throw new AssertionError("Autocomplete suggestion did not appear for " + fieldName + ": " + value, e);
        }
    }

    private void typeOnly(By fieldLocator, String value) {
        WebElement field = wait.until(ExpectedConditions.elementToBeClickable(fieldLocator));
        field.clear();
        field.sendKeys(value);
    }

    private void setDate(By dateLocator, String date) {
        WebElement field = wait.until(ExpectedConditions.presenceOfElementLocated(dateLocator));
        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].removeAttribute('readonly');" +
                "arguments[0].value = arguments[1];" +
                "arguments[0].dispatchEvent(new Event('input', { bubbles: true }));" +
                "arguments[0].dispatchEvent(new Event('change', { bubbles: true }));",
                field,
                date
        );
    }

    private void clickIfPresent(By locator) {
        List<WebElement> elements = driver.findElements(locator);
        if (!elements.isEmpty()) {
            WebElement element = elements.get(0);
            wait.until(ExpectedConditions.elementToBeClickable(element));
            if (!element.isSelected()) {
                element.click();
            }
        }
    }

    private boolean isVisible(By locator) {
        try {
            return wait.until(ExpectedConditions.visibilityOfElementLocated(locator)).isDisplayed();
        } catch (TimeoutException e) {
            return false;
        }
    }

    private boolean hasInvalidRequiredFields() {
        List<WebElement> fields = driver.findElements(By.cssSelector("input, select, textarea"));
        for (WebElement field : fields) {
            Object valid = ((JavascriptExecutor) driver).executeScript("return arguments[0].checkValidity ? arguments[0].checkValidity() : true;", field);
            if (Boolean.FALSE.equals(valid)) {
                return true;
            }
        }
        return false;
    }
}
