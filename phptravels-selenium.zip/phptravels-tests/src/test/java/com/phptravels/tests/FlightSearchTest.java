package com.phptravels.tests;

import com.phptravels.pages.FlightPage;
import com.phptravels.utils.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;

public class FlightSearchTest extends BaseTest {

    private static final String DEPARTURE_DATE = futureDate(45);
    private static final String RETURN_DATE = futureDate(52);
    private static final String INVALID_DEPARTURE_DATE = futureDate(52);
    private static final String INVALID_RETURN_DATE = futureDate(45);

    @Test(description = "Happy path: one-way search returns results for a valid route")
    public void testOneWayFlightSearch() {
        FlightPage flightPage = new FlightPage(driver);
        flightPage.navigateTo(BASE_URL);
        flightPage.selectOneWay();
        flightPage.enterOrigin("London");
        flightPage.enterDestination("Dubai");
        flightPage.setDepartureDate(DEPARTURE_DATE);
        flightPage.clickSearch();

        Assert.assertTrue(flightPage.areResultsDisplayed(),
                "Flight results should be shown for a valid one-way search");
    }

    @Test(description = "Happy path: round-trip search returns results for a valid route")
    public void testRoundTripFlightSearch() {
        FlightPage flightPage = new FlightPage(driver);
        flightPage.navigateTo(BASE_URL);
        flightPage.selectRoundTrip();
        flightPage.enterOrigin("London");
        flightPage.enterDestination("New York");
        flightPage.setDepartureDate(DEPARTURE_DATE);
        flightPage.setReturnDate(RETURN_DATE);
        flightPage.clickSearch();

        Assert.assertTrue(flightPage.areResultsDisplayed(),
                "Flight results should be shown for a valid round-trip search");
    }

    @Test(description = "Happy path: results list is non-empty")
    public void testFlightResultsCount() {
        FlightPage flightPage = new FlightPage(driver);
        flightPage.navigateTo(BASE_URL);
        flightPage.selectOneWay();
        flightPage.enterOrigin("London");
        flightPage.enterDestination("Dubai");
        flightPage.setDepartureDate(DEPARTURE_DATE);
        flightPage.clickSearch();

        Assert.assertTrue(flightPage.getResultCount() > 0,
                "At least one flight result should appear for a valid route");
    }

    @Test(description = "Edge case: searching without filling required fields shows validation or no results")
    public void testFlightSearchWithEmptyFields() {
        FlightPage flightPage = new FlightPage(driver);
        flightPage.navigateTo(BASE_URL);
        flightPage.clickSearch();

        Assert.assertTrue(flightPage.isSearchHandledGracefully(),
                "Empty flight search should show validation/no results or remain handled without crashing");
    }

    @Test(description = "Edge case: same origin and destination is rejected or handled")
    public void testFlightSearchSameOriginAndDestination() {
        FlightPage flightPage = new FlightPage(driver);
        flightPage.navigateTo(BASE_URL);
        flightPage.selectOneWay();
        flightPage.enterOrigin("Dubai");
        flightPage.enterDestination("Dubai");
        flightPage.setDepartureDate(DEPARTURE_DATE);
        flightPage.clickSearch();

        Assert.assertTrue(flightPage.isSearchHandledGracefully(),
                "Identical origin and destination should be rejected, show no results, or be handled without crashing");
    }

    @Test(description = "Edge case: return date before departure date is rejected or handled")
    public void testReturnDateBeforeDeparture() {
        FlightPage flightPage = new FlightPage(driver);
        flightPage.navigateTo(BASE_URL);
        flightPage.selectRoundTrip();
        flightPage.enterOrigin("London");
        flightPage.enterDestination("Dubai");
        flightPage.setDepartureDate(INVALID_DEPARTURE_DATE);
        flightPage.setReturnDate(INVALID_RETURN_DATE);
        flightPage.clickSearch();

        Assert.assertTrue(flightPage.isSearchHandledGracefully(),
                "Return date earlier than departure should be rejected or handled without crashing");
    }

    @Test(description = "Edge case: invalid destination text shows validation or no results")
    public void testInvalidDestinationSearch() {
        FlightPage flightPage = new FlightPage(driver);
        flightPage.navigateTo(BASE_URL);
        flightPage.selectOneWay();
        flightPage.enterOrigin("London");
        flightPage.enterDestinationWithoutSuggestion("Xyzabc12345Nonexistent");
        flightPage.setDepartureDate(DEPARTURE_DATE);
        flightPage.clickSearch();

        Assert.assertTrue(flightPage.isSearchHandledGracefully(),
                "Invalid destination should be rejected or return no results without crashing");
    }
}
