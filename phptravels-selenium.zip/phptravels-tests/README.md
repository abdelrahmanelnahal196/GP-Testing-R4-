# PHPTravels Selenium Test Automation

Automated UI test project for PHPTravels using Java, Selenium WebDriver, TestNG, Maven, WebDriverManager, and Page Object Model.

## Covered areas

- Login
- Registration
- Flight search
- Hotel search
- Positive, negative, and edge-case scenarios

## Main improvements in this fixed version

- Replaced hardcoded past dates with dynamic future dates.
- Added configurable `baseUrl`, `browser`, `headless`, and `timeout` values.
- Added screenshot capture on test failure under `target/screenshots`.
- Removed implicit wait and kept explicit waits only.
- Improved Page Object locators with safer fallback selectors.
- Improved JavaScript date entry by dispatching `input` and `change` events.
- Removed silent autocomplete failures for valid test data.
- Added separate methods for invalid/unknown values that should not require autocomplete suggestions.
- Strengthened assertions so edge cases check validation/no-results/handled states instead of only checking the URL.
- Removed the incorrectly generated `{pages,tests,utils}` folder.

## Requirements

- Java 11+
- Maven
- Chrome, Firefox, or Edge installed

## Run all tests

```bash
mvn clean test
```

## Run with a specific browser

```bash
mvn clean test -Dbrowser=chrome
mvn clean test -Dbrowser=firefox
mvn clean test -Dbrowser=edge
```

## Run headless

```bash
mvn clean test -Dheadless=true
```

## Run against another environment

```bash
mvn clean test -DbaseUrl=https://phptravels.net
```

## Run with all common options

```bash
mvn clean test -Dbrowser=chrome -Dheadless=true -DbaseUrl=https://phptravels.net
```

## Failure evidence

When a test fails, a screenshot is saved automatically in:

```text
target/screenshots
```

## Notes

PHPTravels demo pages can change without notice. If the application markup changes, update the locators inside the Page Object classes only.
