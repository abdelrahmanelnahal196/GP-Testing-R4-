package com.phptravels.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class RegisterPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    private final By firstNameField = By.cssSelector("input[name='firstname'], input[name='first_name']");
    private final By lastNameField = By.cssSelector("input[name='lastname'], input[name='last_name']");
    private final By phoneField = By.cssSelector("input[name='phone'], input[name='mobile']");
    private final By emailField = By.cssSelector("input[name='email'], input[type='email']");
    private final By passwordField = By.cssSelector("input[name='password'], input[type='password']");
    private final By signupButton = By.cssSelector("form button[type='submit'], button[type='submit'], input[type='submit']");
    private final By successMessage = By.cssSelector(".alert-success, .success, .text-success");
    private final By errorMessage = By.cssSelector(".alert-danger, .parsley-required, .invalid-feedback, .error, .text-danger");

    public RegisterPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    public void navigateTo(String baseUrl) {
        driver.get(baseUrl + "/account/signup");
    }

    public void fillRegistrationForm(String firstName, String lastName, String phone, String email, String password) {
        type(firstNameField, firstName);
        type(lastNameField, lastName);
        type(phoneField, phone);
        type(emailField, email);
        type(passwordField, password);
    }

    public void clickSignUp() {
        wait.until(ExpectedConditions.elementToBeClickable(signupButton)).click();
    }

    public boolean isSuccessMessageDisplayed() {
        return isVisible(successMessage);
    }

    public boolean isErrorDisplayed() {
        return isVisible(errorMessage) || hasEmptyRequiredField();
    }

    private void type(By locator, String value) {
        WebElement field = wait.until(ExpectedConditions.elementToBeClickable(locator));
        field.clear();
        field.sendKeys(value);
    }

    private boolean isVisible(By locator) {
        try {
            return wait.until(ExpectedConditions.visibilityOfElementLocated(locator)).isDisplayed();
        } catch (TimeoutException e) {
            return false;
        }
    }

    private boolean hasEmptyRequiredField() {
        return driver.findElements(By.cssSelector("input:required")).stream()
                .anyMatch(field -> field.getAttribute("value") == null || field.getAttribute("value").isEmpty());
    }
}
