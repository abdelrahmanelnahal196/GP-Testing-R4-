package com.phptravels.tests;

import com.phptravels.pages.HotelPage;
import com.phptravels.utils.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;

public class HotelSearchTest extends BaseTest {

    private static final String CHECK_IN_DATE = futureDate(45);
    private static final String CHECK_OUT_DATE = futureDate(50);
    private static final String INVALID_CHECK_IN_DATE = futureDate(50);
    private static final String INVALID_CHECK_OUT_DATE = futureDate(45);

    @Test(description = "Happy path: searching a valid city returns hotel results")
    public void testHotelSearchValidCity() {
        HotelPage hotelPage = new HotelPage(driver);
        hotelPage.navigateTo(BASE_URL);
        hotelPage.enterLocation("Dubai");
        hotelPage.setCheckIn(CHECK_IN_DATE);
        hotelPage.setCheckOut(CHECK_OUT_DATE);
        hotelPage.clickSearch();

        Assert.assertTrue(hotelPage.areResultsDisplayed(),
                "Hotel results should be displayed for a valid city search");
    }

    @Test(description = "Happy path: results list contains at least one hotel")
    public void testHotelResultsCount() {
        HotelPage hotelPage = new HotelPage(driver);
        hotelPage.navigateTo(BASE_URL);
        hotelPage.enterLocation("London");
        hotelPage.setCheckIn(CHECK_IN_DATE);
        hotelPage.setCheckOut(CHECK_OUT_DATE);
        hotelPage.clickSearch();

        Assert.assertTrue(hotelPage.getResultCount() > 0,
                "At least one hotel should be returned for a popular city");
    }

    @Test(description = "Happy path: first hotel result has a non-empty name")
    public void testHotelResultHasName() {
        HotelPage hotelPage = new HotelPage(driver);
        hotelPage.navigateTo(BASE_URL);
        hotelPage.enterLocation("New York");
        hotelPage.setCheckIn(CHECK_IN_DATE);
        hotelPage.setCheckOut(CHECK_OUT_DATE);
        hotelPage.clickSearch();

        String firstName = hotelPage.getFirstHotelName();
        Assert.assertFalse(firstName.isEmpty(), "First hotel name should not be empty");
    }

    @Test(description = "Edge case: empty search shows validation or no results")
    public void testHotelSearchEmptyFields() {
        HotelPage hotelPage = new HotelPage(driver);
        hotelPage.navigateTo(BASE_URL);
        hotelPage.clickSearch();

        Assert.assertTrue(hotelPage.isSearchHandledGracefully(),
                "Empty hotel search should show validation/no results or be handled without crashing");
    }

    @Test(description = "Edge case: check-out date before check-in is rejected or handled")
    public void testCheckOutBeforeCheckIn() {
        HotelPage hotelPage = new HotelPage(driver);
        hotelPage.navigateTo(BASE_URL);
        hotelPage.enterLocation("Dubai");
        hotelPage.setCheckIn(INVALID_CHECK_IN_DATE);
        hotelPage.setCheckOut(INVALID_CHECK_OUT_DATE);
        hotelPage.clickSearch();

        Assert.assertTrue(hotelPage.isSearchHandledGracefully(),
                "Check-out before check-in should be rejected or handled without crashing");
    }

    @Test(description = "Edge case: unknown location shows no results or validation")
    public void testHotelSearchUnknownLocation() {
        HotelPage hotelPage = new HotelPage(driver);
        hotelPage.navigateTo(BASE_URL);
        hotelPage.enterLocationWithoutSuggestion("Xyzabc12345Nonexistent");
        hotelPage.setCheckIn(CHECK_IN_DATE);
        hotelPage.setCheckOut(CHECK_OUT_DATE);
        hotelPage.clickSearch();

        Assert.assertTrue(hotelPage.isSearchHandledGracefully(),
                "Searching an unknown location should show validation/no results without crashing");
    }

    @Test(description = "Edge case: same-day check-in and check-out is rejected or handled")
    public void testSameDayCheckInCheckOut() {
        HotelPage hotelPage = new HotelPage(driver);
        hotelPage.navigateTo(BASE_URL);
        hotelPage.enterLocation("Dubai");
        hotelPage.setCheckIn(CHECK_IN_DATE);
        hotelPage.setCheckOut(CHECK_IN_DATE);
        hotelPage.clickSearch();

        Assert.assertTrue(hotelPage.isSearchHandledGracefully(),
                "Same-day check-in/check-out should be rejected or handled without crashing");
    }
}
