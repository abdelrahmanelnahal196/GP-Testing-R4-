package com.phptravels.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class LoginPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    private final By emailField = By.cssSelector("input[name='username'], input[name='email'], input[type='email']");
    private final By passwordField = By.cssSelector("input[name='password'], input[type='password']");
    private final By loginButton = By.cssSelector("form button[type='submit'], button[type='submit'], input[type='submit']");
    private final By errorMessage = By.cssSelector(".alert-danger, .error-msg, .invalid-feedback, .text-danger");
    private final By accountMenu = By.cssSelector("li.dropdown a.dropdown-toggle, .dashboard, .account, a[href*='account']");
    private final By logoutLink = By.cssSelector("a[href*='logout'], a[href*='signout']");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    public void navigateTo(String baseUrl) {
        driver.get(baseUrl + "/account/login");
    }

    public void enterEmail(String email) {
        WebElement field = wait.until(ExpectedConditions.elementToBeClickable(emailField));
        field.clear();
        field.sendKeys(email);
    }

    public void enterPassword(String password) {
        WebElement field = wait.until(ExpectedConditions.elementToBeClickable(passwordField));
        field.clear();
        field.sendKeys(password);
    }

    public void clickLogin() {
        wait.until(ExpectedConditions.elementToBeClickable(loginButton)).click();
    }

    public void login(String email, String password) {
        enterEmail(email);
        enterPassword(password);
        clickLogin();
    }

    public boolean isLoggedIn() {
        try {
            wait.until(ExpectedConditions.or(
                    ExpectedConditions.urlContains("dashboard"),
                    ExpectedConditions.urlContains("account/dashboard"),
                    ExpectedConditions.visibilityOfElementLocated(accountMenu)
            ));
            return driver.findElements(errorMessage).isEmpty()
                    && !driver.getCurrentUrl().contains("/account/login");
        } catch (TimeoutException e) {
            return false;
        }
    }

    public String getErrorMessage() {
        try {
            return wait.until(ExpectedConditions.visibilityOfElementLocated(errorMessage)).getText().trim();
        } catch (TimeoutException e) {
            return "";
        }
    }

    public boolean isErrorDisplayed() {
        return !getErrorMessage().isEmpty();
    }

    public void logout() {
        wait.until(ExpectedConditions.elementToBeClickable(accountMenu)).click();
        wait.until(ExpectedConditions.elementToBeClickable(logoutLink)).click();
    }
}
